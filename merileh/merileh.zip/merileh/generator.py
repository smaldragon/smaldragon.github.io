import json

font = {"providers":[]}

with open("unicode.txt") as f:
    for line in f.readlines():
        data = line.split(" ")
        print(data)
        font["providers"].append({
        "type":"bitmap",
        "file":f'minecraft:merileh/merileh_{data[0]}.png',
        "ascent":8,
        "height":8,
        "chars":[f'{data[-1][0]}']
        })

with open('assets/minecraft/font/default.json', 'w') as f:
    f.write(json.dumps(font, ensure_ascii=False, indent=4))